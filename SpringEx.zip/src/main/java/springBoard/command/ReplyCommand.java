package springBoard.command;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import springBoard.model.JDBCTemplateDAO;
import springBoard.model.SpringBbsDAO;
import springBoard.model.SpringBbsDTO;

public class ReplyCommand implements BbsCommand{

	@Override
	public void execute(Model model) {
		
		// 파라미터 한 번에 받기
		Map<String, Object> paramMap = model.asMap();
		HttpServletRequest req = (HttpServletRequest)paramMap.get("req");
		
		String idx = req.getParameter("idx");
		
		//SpringBbsDAO dao = new SpringBbsDAO();
		JDBCTemplateDAO dao = new JDBCTemplateDAO();
		
		SpringBbsDTO dto = dao.view(idx);
		
		dto.setTitle("[Re]" + dto.getTitle());
		dto.setContents("\r\n\r\n\r\n[원본글입니다.]\r\n" + dto.getContents());
		
		model.addAttribute("viewRow", dto);
		dao.close();
	}

}
