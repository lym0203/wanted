package springBoard.command;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import springBoard.model.JDBCTemplateDAO;
import springBoard.model.SpringBbsDAO;
import springBoard.model.SpringBbsDTO;

public class ReplyActionCommand implements BbsCommand{

	@Override
	public void execute(Model model) {
		
		// 파라미터 한 번에 받기
		Map<String, Object> paramMap = model.asMap();
		HttpServletRequest req = (HttpServletRequest)paramMap.get("req");
		
		String nowPage = req.getParameter("nowPage");
		
		String name = req.getParameter("name");
		String title = req.getParameter("title");
		String pass = req.getParameter("pass");
		String contents = req.getParameter("contents");
		// 답변글쓰기를 위한 로직 추가
		String bgroup = req.getParameter("bgroup");
		String bstep = req.getParameter("bstep");
		String bindent = req.getParameter("bindent");
		
		/*SpringBbsDTO dto = new SpringBbsDTO();
		dto.setContents(contents);
		dto.setTitle(title);
		dto.setName(name);
		dto.setPass(pass);
		// 답변글쓰기를 위한 로직 추가
		dto.setBgroup(Integer.parseInt(bgroup));
		dto.setBstep(Integer.parseInt(bstep));
		dto.setBindent(Integer.parseInt(bindent));*/
		
		//SpringBbsDAO dao = new SpringBbsDAO();
		JDBCTemplateDAO dao = new JDBCTemplateDAO();
		
		dao.reply(name, title, contents, bgroup, bstep, bindent, pass);
		
		model.addAttribute("nowPage", nowPage);
		
		dao.close();
	}

}
