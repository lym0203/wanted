package springBoard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletContext;
import javax.sql.DataSource;

public class SpringBbsDAO {

	Connection con;
	PreparedStatement psmt;
	ResultSet rs;
	
	//생성자 : 커넥션풀을 이용한 DB연결
	public SpringBbsDAO()
	{
		try {
			Context ctx2 = new InitialContext();
			DataSource source = (DataSource)ctx2.lookup("java:comp/env/jdbc/myoracle");
			
			con = source.getConnection();
			System.out.println("Spring Board DB연결 성공");
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("Spring Board DB연결 실패");
		}
	}
	
	//자원반납 : 연결해제가 아니라 커넥션풀에 다시 반납하는 것임.
	public void close(){
		try{
			if(rs!=null) rs.close();
			if(psmt!=null) psmt.close();
			if(con!=null) con.close();
		}
		catch(Exception e){}
	}
	
	// 전체목록 카운트하기
	public int getTotalCount(Map<String, Object> map) {
		
		int totalRecord = 0;
		
		try {
			String sql = "select count(*) from springboard";
			
			// 검색 기능 구현
			if(map.get("keyString") != null) {
				sql += " where " + map.get("keyField") + " like '%" + map.get("keyString") + "%'";
			}
			
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			rs.next();
			totalRecord = rs.getInt(1);
		}
		catch(Exception e) {
			
		}
		
		return totalRecord;
	}
	
	// 리스트 가져오기
	public ArrayList<SpringBbsDTO> list(Map<String, Object> map){
		
		ArrayList<SpringBbsDTO> lists = new ArrayList<SpringBbsDTO>();
		
		String sql = "select * from (select Tb.*, rownum rNum from (select * from springboard ";
		if(map.get("keyString") != null) {
			sql += " where " + map.get("keyField") + " like '%" + map.get("keyString") + "%'";
		}
			sql += " order by bgroup desc, bstep asc) TB ) " + 
			" where rNum between ? and ?";
			
			System.out.println("쿼리문 : " + sql);
		
		try {
			// 3. prepare 객체 생성 및 실행
			psmt = con.prepareStatement(sql);
			
			psmt.setInt(1, Integer.parseInt(map.get("start").toString()));
			psmt.setInt(2, Integer.parseInt(map.get("end").toString()));
			
			rs = psmt.executeQuery();
			while(rs.next()) {
				// 4. 결과셋을 DTO객체에 담는다.
				SpringBbsDTO dto = new SpringBbsDTO();
				
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setTitle(rs.getString(3));
				dto.setContents(rs.getString(4));
				dto.setPostdate(rs.getDate(5));
				dto.setHits(rs.getInt(6));
				dto.setBgroup(rs.getInt(7));
				dto.setBstep(rs.getInt(8));
				dto.setBindent(rs.getInt(9));
				dto.setPass(rs.getString(10));
				
				lists.add(dto);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return lists;
	}
	
	// 글쓰기 처리
	public void write(String name, String title, String contents, String pass) {
		
		try {
			String sql = "insert into springboard (idx, name, title, contents, hits, "
					+ " bgroup, bstep, bindent, pass) "
					+ " values (springboard_seq.nextval, ?, ?, ?, 0, springboard_seq.nextval, 0, 0, ?)";
			
			psmt = con.prepareStatement(sql);
			psmt.setString(1, name);
			psmt.setString(2, title);
			psmt.setString(3, contents);
			psmt.setString(4, pass);
			
			int rn = psmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 게시물 상세보기
	public SpringBbsDTO view(String idx) {
		
		SpringBbsDTO dto = null;
		
		try {
			String sql = "select * from springboard where idx=?";
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, Integer.parseInt(idx));
			rs = psmt.executeQuery();
			if(rs.next()) {
				dto = new SpringBbsDTO();
				
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setTitle(rs.getString(3));
				/*
				 * 내용은 줄바꿈 처리해야함(수정에서도 해당 메소드를 같이 사용하기 위해 줄바꿈 처리는 command에서 함)
				 */
				dto.setContents(rs.getString(4));
				dto.setPostdate(rs.getDate(5));
				dto.setHits(rs.getInt(6));
				dto.setBgroup(rs.getInt(7));
				dto.setBstep(rs.getInt(8));
				dto.setBindent(rs.getInt(9));
				dto.setPass(rs.getString(10));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return dto;
	}
	
	// 패스워드 검증
	public int password(String idx, String pass) {
		
		int returnNum = 0;
		try {
			String sql = "select * from springboard where idx=? and pass=?";
			
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, Integer.parseInt(idx));
			psmt.setString(2, pass);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				// 조건에 맞는 게시물이 있다면 idx값은 무조건 0이상이므로 0인지 여부를 확인하면 된다.
				returnNum = rs.getInt(1);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return returnNum;
	}
	
	// 수정 처리
	public void modify(String idx, String name, String title, String contents, String pass) {
		
		try {
			String sql = "update springboard set name=?, title=?, contents=? where idx=? and pass=?";
			psmt = con.prepareStatement(sql);
			psmt.setString(1, name);
			psmt.setString(2, title);
			psmt.setString(3, contents);
			psmt.setInt(4, Integer.parseInt(idx));
			psmt.setString(5, pass);
			
			int rn = psmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 삭제 처리
	public void delete(String idx) {
		
		try {
			String sql = "delete from springboard where idx=?";
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, Integer.parseInt(idx));
			
			int rn = psmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 게시물 답변글달기(reply)
	public int reply(SpringBbsDTO dto) {
	// 답변글 달기 전 bstep+1 증가시킴
	replyStepUpdate(dto.getBgroup(), dto.getBstep());
	
	int affected = 0; // 적용된 행의 갯수
	
	try {
		String sql = "insert into springboard "
				+ " (idx, name, title, contents, hits, bgroup, bstep, bindent, pass) "
				+ " values (springboard_seq.nextval, ?, ?, ?, 0, ?, ?, ?, ?)";
	
		psmt = con.prepareStatement(sql);
		psmt.setString(1, dto.getName());
		psmt.setString(2, dto.getTitle());
		psmt.setString(3, dto.getContents());
		psmt.setInt(4, dto.getBgroup());
		psmt.setInt(5, dto.getBstep()+1);
		psmt.setInt(6, dto.getBindent()+1);
		psmt.setString(7, dto.getPass());
			
		affected = psmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return affected;
	}
	
	// 답변글 입력 전 해당 그룹 내 레코드 일괄 업데이트
	public void replyStepUpdate(int groupNum, int stepNum) {
		
		try {
			String sql = "update springboard set bstep=bstep+1 where bgroup=? and bstep>?";
			
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, groupNum);
			psmt.setInt(2, stepNum);
			
			psmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
