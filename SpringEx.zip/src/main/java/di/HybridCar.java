package di;

public class HybridCar implements Car{

	@Override
	public String myDrive() {
		
		return "하이브리드카를 타고 드라이브를 즐깁니다.";
	}
}
