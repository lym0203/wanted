package di;

public class SportsCar implements Car{

	@Override
	public String myDrive() {
		
		return "스포츠카를 타고 드라이브를 즐깁니다.";
	}
}
