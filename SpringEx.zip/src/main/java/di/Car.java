package di;

public interface Car {

	// 하위 클래스에서 오버라이딩할 추상메소드 정의
	public String myDrive();
}
