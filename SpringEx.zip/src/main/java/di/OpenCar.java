package di;

public class OpenCar implements Car{

	@Override
	public String myDrive() {
		
		return "오픈카를 타고 드라이브를 즐깁니다.";
	}
}
