package transaction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

public class TicketDAO {

	// 스프링 JDBC 사용
	JdbcTemplate template;
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	/*
	 * [트랜젝션2에서 추가함]
	 * 트랜젝션 처리를 위한 참조변수와 세터 설정
	 * servlet-context.xml에서 생성한 transactionManager빈을 주입받음
	 */
	PlatformTransactionManager transactionManager;
	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}
	
	// 기본 생성자
	public TicketDAO() {
		System.out.println(template);
	}
	
	// 티켓 구매위한 메소드 정의
	public void buyTicket(final TicketDTO dto) {
		
		System.out.println("buyTicket()메소드 호출");
		System.out.println(dto.getCustomerId()+"님이 티켓 "+dto.getAmount()+"장을 구매합니다.");
		
		/*
		 * [트랜젝션2에서 추가함]
		 * 트랜젝션을 사용하기 위해 기본적으로 필요한 객체 생성
		 */
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		
		try {
			// 결제 금액 처리
			template.update(new PreparedStatementCreator() {
				
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					// 신용카드 결제내역 인서트
					String query = "insert into transaction_pay (customerId, amount) values (?, ?)";
					PreparedStatement psmt = con.prepareStatement(query);
					psmt.setString(1, dto.getCustomerId());
					psmt.setInt(2, dto.getAmount()*10000);
					
					return psmt;
				}
			});
			
			// 티켓 구매 처리
			template.update(new PreparedStatementCreator() {
				
				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					// 티켓 구매 내역 인서트
					String query = "insert into transaction_ticket (customerId, countNum) values (?, ?)";
					PreparedStatement psmt = con.prepareStatement(query);
					psmt.setString(1, dto.getCustomerId());
					psmt.setInt(2, dto.getAmount());
					
					return psmt;
				}
			});
			
			System.out.println("카드결제와 구매 모두 정상처리 되었습니다.");
			System.out.println("구매해주셔서 감사합니다.");
			transactionManager.commit(status);
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("제약조건을 위배하여 카드결제와 티켓구매가 모두 취소되었습니다.");
			transactionManager.rollback(status);
		}
	}
	
}
