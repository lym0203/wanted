package transaction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

public class TicketTplDAO {

	// 스프링 JDBC 사용
	JdbcTemplate template;
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	// 트랜젝션3에서 사용 : 트랜젝션 템플릿 사용위한 추가 부분
	TransactionTemplate transactionTemplate;
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	
	// 기본 생성자
	public TicketTplDAO() {
		System.out.println(template);
	}
	
	// 티켓 구매위한 메소드 정의
	public boolean buyTicket(final TicketDTO dto) {
		
		System.out.println("buyTicket()메소드 호출");
		System.out.println(dto.getCustomerId()+"님이 티켓 "+dto.getAmount()+"장을 구매합니다.");
		
		/*
		 * [트랜젝션2에서 추가함]
		 * 트랜젝션 템플릿을 사용하면 이 부분은 필요 없음.
		 */
		/*TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = tranMgr.getTransaction(def);*/
		
		try {
			
			transactionTemplate.execute(new TransactionCallbackWithoutResult() {
				
				@Override
				protected void doInTransactionWithoutResult(TransactionStatus arg0) {
					
					// 결제 금액 처리
					template.update(new PreparedStatementCreator() {
						
						@Override
						public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
							// 신용카드 결제내역 인서트
							String query = "insert into transaction_pay (customerId, amount) values (?, ?)";
							PreparedStatement psmt = con.prepareStatement(query);
							psmt.setString(1, dto.getCustomerId());
							psmt.setInt(2, dto.getAmount()*10000);
							
							return psmt;
						}
					});
					
					// 티켓 구매 처리
					template.update(new PreparedStatementCreator() {
						
						@Override
						public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
							// 티켓 구매 내역 인서트
							String query = "insert into transaction_ticket (customerId, countNum) values (?, ?)";
							PreparedStatement psmt = con.prepareStatement(query);
							psmt.setString(1, dto.getCustomerId());
							psmt.setInt(2, dto.getAmount());
							
							return psmt;
						}
					});
				}
			});
			
			System.out.println("카드결제와 구매 모두 정상처리 되었습니다.");
			System.out.println("구매해주셔서 감사합니다.");
			return true;
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("제약조건을 위배하여 카드결제와 티켓구매 모두가 취소되었습니다.");
			return false;
		}
	}
	
}
