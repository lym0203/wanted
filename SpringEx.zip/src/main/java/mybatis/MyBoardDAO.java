package mybatis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;

import springBoard.model.SpringBbsDTO;

public class MyBoardDAO implements MyBoardDAOImpl{
	
	// 기본 생성자
	public MyBoardDAO() {}
	
	// JdbcTemplate 사용하기
	JdbcTemplate template;
	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public ArrayList<MyBoardDTO> list() {
		
		String query = "select * from myboard order by idx desc";
		
		ArrayList<MyBoardDTO> lists = (ArrayList<MyBoardDTO>)template.query(query, new BeanPropertyRowMapper<MyBoardDTO>(MyBoardDTO.class));
		
		return lists;
	}

	@Override
	public void write(final String name, final String contents, final String id) {
		
		this.template.update(new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				String query = "insert into myboard (idx, name, contents, id) values (myboard_seq.nextval, ?, ?, ?)";
				
				PreparedStatement psmt = con.prepareStatement(query);
				psmt.setString(1, name);
				psmt.setString(2, contents);
				psmt.setString(3, id);
				return psmt;
			}
		});
	}
	
	@Override
	public MyBoardDTO view(String idx, String id) {
		
		MyBoardDTO dto = null;
		String query = "select * from myboard where idx="+idx+" and id='"+id+"'";
		
		try {
			return template.queryForObject(query, new BeanPropertyRowMapper<MyBoardDTO>(MyBoardDTO.class));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return dto;
	}

	@Override
	public void modify(final String idx, final String name, final String contents, final String id) {
		
		String query = "update myboard set name=?, contents=? where idx=? and id=?";
		
		this.template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement psmt) throws SQLException{
				psmt.setString(1, name);
				psmt.setString(2, contents);
				psmt.setString(3, idx);
				psmt.setString(4, id);
			}
		});
	}

	@Override
	public void delete(final String idx, final String id) {
		
		String query = "delete from myboard where idx=? and id=?";
		
		this.template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement psmt) throws SQLException {
				
				psmt.setInt(1, Integer.parseInt(idx));
				psmt.setString(2, id);
			}
		});
	}

	@Override
	public MemberDTO login(String id, String pass) {
		
		String query = "select * from member where id='" + id + "' and pass='" + pass + "'";
		
		MemberDTO memberDTO = null;
		
		try {
			memberDTO = template.queryForObject(query, new BeanPropertyRowMapper<MemberDTO>(MemberDTO.class));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return memberDTO;
	}
	
}
