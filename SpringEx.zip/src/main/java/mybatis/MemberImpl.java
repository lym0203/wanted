package mybatis;

public interface MemberImpl {

	public MemberDTO login(String id, String pass);
}
